import javax.swing.JOptionPane;
public class lab1_3 {
    public static void main(String [] args){
        String result = JOptionPane.showInputDialog("Please enter your name : ");
        JOptionPane.showMessageDialog(null,"Hi " + result + "!");
        System.exit(0);
    }
}
