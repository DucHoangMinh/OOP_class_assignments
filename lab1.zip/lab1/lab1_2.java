import javax.swing.JOptionPane;
public class lab1_2 {
    public static void main(String [] args){
        JOptionPane.showMessageDialog(null,"Hello World ! How are you?");
        System.exit(0);
    }
}
